@SuppressWarnings("serial")
public class BillLessthanZeroException extends Throwable{
	    public BillLessthanZeroException(String billValue) {
	        super(billValue);
	}
}
